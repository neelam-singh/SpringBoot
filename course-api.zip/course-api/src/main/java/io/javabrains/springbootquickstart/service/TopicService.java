package io.javabrains.springbootquickstart.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.stereotype.Service;
import io.javabrains.springbootquickstart.entity.Topic;

@Service
public class TopicService {
	
	private List<Topic> topicList = new ArrayList<>(Arrays.asList(
			new Topic("1", "Java", "JavaTopic"),
			new Topic("2", "RestAPI", "RestAPITopic"),
			new Topic("3", "Spring", "SpringTopic"),
			new Topic("4", "SpringBoot", "SpringBootTopic")
			));
	
	public List<Topic> getAllTopics()
	{
		return topicList;
	}
	
	public Topic getTopic(String id)
	{
		return topicList.stream().filter(t->t.getId().equals(id)).findFirst().get();
	}

	public void addTopic(Topic topic)
	{
		topicList.add(topic);
	}

	public void updateTopic(Topic topic, String id) {
		for (int i = 0; i < topicList.size(); i++) {
			
			if(topicList.get(i).getId().equals(id))
			{
				topicList.set(i, topic);
			}
		}
		
	}

	public void deleteTopic(String id) {
		for (int i = 0; i < topicList.size(); i++) {

			if (topicList.get(i).getId().equals(id)) {
				topicList.remove(i);
			}
		}
	}
}
