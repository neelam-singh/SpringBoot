package io.javabrains.springbootquickstart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseApidataApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseApidataApplication.class, args);
	}

}
