package io.javabrains.springbootquickstart.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.javabrains.springbootquickstart.Repo.TopicRepository;
import io.javabrains.springbootquickstart.entity.Topic;

@Service
public class TopicService {
	
	@Autowired
	private TopicRepository topicRep;
	
	private List<Topic> topicList = new ArrayList<>(Arrays.asList(
			new Topic("1", "Java", "JavaTopic"),
			new Topic("2", "RestAPI", "RestAPITopic"),
			new Topic("3", "Spring", "SpringTopic"),
			new Topic("4", "SpringBoot", "SpringBootTopic")
			));
	
	public List<Topic> getAllTopics()
	{
		List<Topic> topics = new ArrayList<>();
		topicRep.findAll().forEach(topics::add);
		return topics;
	}
	
	public Optional<Topic> getTopic(String id)
	{
		return topicRep.findById(id);
	}

	public void addTopic(Topic topic)
	{
		topicRep.save(topic);
	}

	public void updateTopic(Topic topic, String id) {
		topicRep.save(topic);
	}

	public void deleteTopic(String id) {
		topicRep.deleteById(id);
	}
}
