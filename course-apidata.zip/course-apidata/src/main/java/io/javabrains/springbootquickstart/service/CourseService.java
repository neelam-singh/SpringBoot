package io.javabrains.springbootquickstart.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import io.javabrains.springbootquickstart.Repo.CourseRepository;
import io.javabrains.springbootquickstart.entity.Course;
import io.javabrains.springbootquickstart.entity.Topic;

@Service
public class CourseService {
	
	@Autowired
	private CourseRepository courseRep;
	
	private List<Topic> topicList = new ArrayList<>(Arrays.asList(
			new Topic("1", "Java", "JavaTopic"),
			new Topic("2", "RestAPI", "RestAPITopic"),
			new Topic("3", "Spring", "SpringTopic"),
			new Topic("4", "SpringBoot", "SpringBootTopic")
			));
	
	
	public List<Course> getAllCourses(String topicId)
	{
		List<Course> courses = new ArrayList<>();
		courseRep.findByTopicId(topicId)
		.forEach(courses::add);
		return courses;
	}
	
	public Optional<Course> getTopic(String id)
	{
		return courseRep.findById(id);
	}

	public void addTopic(Course topic)
	{
		courseRep.save(topic);
	}

	public void updateTopic(Course topic, String id) {
		courseRep.save(topic);
	}

	public void deleteTopic(String id) {
		courseRep.deleteById(id);
	}
}
