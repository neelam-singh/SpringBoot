package io.javabrains.springbootquickstart.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.javabrains.springbootquickstart.entity.Course;
import io.javabrains.springbootquickstart.entity.Topic;
import io.javabrains.springbootquickstart.service.CourseService;
import io.javabrains.springbootquickstart.service.TopicService;

@RestController
public class CourseController {
	
	@Autowired
	private CourseService courseService;
	
	@RequestMapping("/topics/{topicid}/courses")
	public List<Course> getAllCourses(@PathVariable String topicid){
		
		return courseService.getAllCourses(topicid);
	}
	
	@RequestMapping("/topics/{topicid}/courses/{id}")
	public Optional<Course> getTopic(@PathVariable String topicid, @PathVariable String id)
	{
		return (Optional<Course>) courseService.getTopic(id);
	}
	
	@RequestMapping(method = RequestMethod.POST, value ="/topics/{topicid}/courses")
	public void addTopic(@RequestBody Course course, @PathVariable String topicid)
	{
		course.setTopic(new Topic(topicid, "", ""));
		courseService.addTopic(course);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/topics/{topicid}/courses/{id}")
	public void updateTopic(@RequestBody Course course, @PathVariable String id, @PathVariable String topicid)
	{
		course.setTopic(new Topic(topicid, "", ""));
		courseService.updateTopic(course, id);
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/topics/{topicid}/courses/{id}")
	public void deleteTopic(@PathVariable String id, @PathVariable String topicid)
	{
		courseService.deleteTopic(id);
	}

}
