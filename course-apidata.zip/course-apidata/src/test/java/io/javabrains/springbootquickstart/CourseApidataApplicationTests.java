package io.javabrains.springbootquickstart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseApidataApplicationTests {

	@Test
	void contextLoads() {
	}

}
